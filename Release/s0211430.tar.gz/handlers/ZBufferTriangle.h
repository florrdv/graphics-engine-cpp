#ifndef __PROJECTS_GRAPHICS_ENGINE_CPP_HANDLERS_ZBUFFERINGTRIANGLES_H_
#define __PROJECTS_GRAPHICS_ENGINE_CPP_HANDLERS_ZBUFFERINGTRIANGLES_H_

#include "../easy_image.h"
#include "../ini_configuration.h"

img::EasyImage zBufferTriangle(const ini::Configuration& c);

#endif // __PROJECTS_GRAPHICS_ENGINE_CPP_HANDLERS_ZBUFFERINGTRIANGLES_H_